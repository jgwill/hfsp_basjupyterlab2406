export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH
cd ..
./StrategyRunner samples/ma_advisor_conf.ini
