export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH
cd ..
./StrategyRunner samples/dmacd_conf.ini