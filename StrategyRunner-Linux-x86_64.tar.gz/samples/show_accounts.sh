export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH
cd ..
./StrategyRunner ./samples/show_accounts.ini
