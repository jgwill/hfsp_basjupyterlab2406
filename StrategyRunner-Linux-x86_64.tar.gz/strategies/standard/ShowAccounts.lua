function Init()
    strategy:name("ShowAccounst");
    strategy:type(core.Signal);
end

timerID = nil

function Prepare(onlyName)
    instance:name(profile:id());

    timerId = core.host:execute("setTimer", 1000, 1);
end


function Update(id, source, period)
end



function AsyncOperationFinished(cookie, success, message, message1, message2)   
    if cookie == 1000 then
        printAccounts()
        core.host:execute("killTimer", timerId);
        core.host:stop()
    end
end


function printAccounts()
    local enum, row;
    enum = core.host:findTable("accounts"):enumerator();
    row = enum:next();
    while(row ~= nil)  do
        ret = row.AccountID
        core.host:trace("Account ID: " .. tostring(row.AccountID) .. ", name: " .. tostring(row.AccountName))
        row = enum:next()
    end 
end


